✅ Telegram Botni Render.com orqali BEPUL ISHLATISH (24/7) YO‘RIQNOMASI

1. Saytga kiring: https://render.com
2. Gmail orqali ro‘yxatdan o‘ting
3. "New Web Service" tugmasini bosing
4. Reponi yuklash: siz ushbu zip faylni GitHub'ga joylashingiz mumkin (yordam kerak bo‘lsa ayting)
5. Build Command: pip install -r requirements.txt
6. Start Command: python main.py
7. Environment > Add Environment Variable:
    Key: BOT_TOKEN
    Value: 7908835811:AAHZOyMpPYZtZfHk2FQ5jQYVQDqMFLhFVBI
8. Free versiyani tanlang, Deploy tugmasini bosing

Tayyor! Bot 24 soat ishlaydi. 
Yordam kerak bo‘lsa, bemalol yozing.
